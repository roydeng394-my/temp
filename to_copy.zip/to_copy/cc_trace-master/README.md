# cc_trace - Claude CLI API 中间人代理

一个用于截获和记录 Claude CLI 与 LLM API 之间完整请求/响应流的代理服务器。

## 功能特性

- 记录完整的 HTTP 请求和响应（包括 headers、body）
- 支持流式（SSE）和非流式响应
- 线程安全的日志写入，支持 ~100 并发
- 双日志格式：逐行日志 + request-response 对日志
- 请求 ID 追踪，便于关联分析

## 文件说明

| 文件 | 说明 |
|------|------|
| `api_proxy.py` | 代理服务器主程序 |
| `test_example.py` | 测试示例脚本 |
| `cli_api_proxy_log.jsonl` | 完整的逐行 API 日志 |
| `cli_api_proxy_messages.jsonl` | request-response 对日志 |

## 快速开始

### 1. 启动代理服务器

```bash
python api_proxy.py
```

代理将在 `http://localhost:8889` 监听请求。

### 2. 运行测试示例

```bash
python test_example.py
```

## 使用方式

### 通过环境变量配置

```python
import os
from claude_agent_sdk import query, ClaudeAgentOptions

os.environ.update({
    "ANTHROPIC_BASE_URL": "http://localhost:8889",
    "ANTHROPIC_MODEL": "GLM",
    "ANTHROPIC_AUTH_TOKEN": "your-token",
})

async for message in query("你好"):
    # 处理响应...
```

### 使用 ClaudeAgentOptions

```python
options = ClaudeAgentOptions(
    env={
        "ANTHROPIC_BASE_URL": "http://localhost:8889",
        "ANTHROPIC_MODEL": "GLM",
    }
)
```

## 日志格式

### cli_api_proxy_log.jsonl (逐行日志)

每条记录包含请求/响应的详细信息：

```json
{
  "type": "downstream_request",
  "rid": "1699999999-a1b2c3d4",
  "path": "/v1/messages",
  "stream": false,
  "headers": {...},
  "body": {...},
  "timestamp": 1699999999123
}
```

### cli_api_proxy_messages.jsonl (消息对日志)

每条记录包含完整的 request-response 对：

```json
{
  "rid": "1699999999-a1b2c3d4",
  "request": {...},
  "response": {...}
}
```

## 配置项

| 环境变量 | 说明 | 默认值 |
|----------|------|--------|
| `UPSTREAM_BASE_URL` | 上游 API 地址 | `http://api.code-agent.rnd.huawei.com` |
| `PROXY_LOG_FILE` | 逐行日志文件路径 | `cli_api_proxy_log.jsonl` |
| `MESSAGES_LOG_FILE` | 消息对日志文件路径 | `cli_api_proxy_messages.jsonl` |

## 代理地址

- 监听地址: `0.0.0.0:8889`
- 本地访问: `http://localhost:8889`