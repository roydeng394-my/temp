"""
代理服务器

监听本地端口，接收 CLI 的 HTTP 请求，记录完整内容，
然后转发给真实的 LLM API，并记录完整响应。
"""
import copy
import json
import time
import uuid
import threading
from flask import Flask, request, Response, stream_with_context
import requests
import os
import asyncio
import httpx
# from mcp.client.streamable_http import streamable_http_client
from mcp import ClientSession
from threading import Lock, Semaphore
from typing import Any
from datetime import datetime, date
import json
import os
import urllib3
urllib3.disable_warnings()

def get_fixed_date_advanced(target_date=None):
    """
    处理2月份特殊情况的版本
    
    Args:
        target_date: 目标日期，默认为今天
        
    Returns:
        datetime: 固定后的日期
    """
    if target_date is None:
        target_date = date.today()
    
    year = target_date.year
    month = target_date.month
    
    if target_date.day <= 15:
        return date(year, month, 15)
    else:
        # 处理2月份没有30号的情况
        if month == 2:
            # 判断是否为闰年
            if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0):
                return date(year, month, 29)  # 闰年2月29天
            else:
                return date(year, month, 28)  # 平年2月28天
        # 处理小月（4,6,9,11月）没有30号的情况
        elif month in [4, 6, 9, 11]:
            return date(year, month, 30)
        else:
            return date(year, month, 30)
# from mcp import ClientSession
# from mcp.client.streamable_http import streamable_http_client


os.environ['http_proxy'] = ""
os.environ['https_proxy'] = ""
# os.environ['http_proxy'] = "http://111.241.2345.314:9090"
# os.environ['https_proxy'] = "http://111.241.2345.314:9090"
app = Flask(__name__)

# 真实的 API 配置
# UPSTREAM_BASE_URL = "http://api.code-agent.rnd.huawei.com"
# UPSTREAM_BASE_URL = "https://api.gptplus5.com"
UPSTREAM_BASE_URL = "https://yibuapi.com"

# Blue-Green Bridge 配置（用于 alias 路由）
BLUE_GREEN_BASE_URL = "https://apigw-dgg-b0.huawei.com/api"
BLUE_GREEN_PREFIX = "/pangu/v1"
X_HW_ID = "S008151"
X_HW_APPKEY = "hgXXZtkXVPDIS97C6obz/w=="
# 默认 alias，可被请求体中的 alias 字段覆盖
DEFAULT_ALIAS = "pangu35b-skill-tool-220"

# 日志文件
PROXY_LOG_FILE = "log/cli_api_proxy_log_" + datetime.now().strftime("%Y-%m-%d.jsonl")
MESSAGES_LOG_FILE = "log/cli_api_proxy_messages_" + datetime.now().strftime("%Y-%m-%d.jsonl")

MCP_SERVER_API_KEY = "0ab4ac1a-d18e-427e-bf11-c762c84db865"
LOG_FILENAME = datetime.now().strftime("%Y-%m-%d.jsonl")
API_KEY = "sk-LLgFQ4TWp5jTf7nKpOz8o9D93I4DplaVMDuZLiVtgBqj7XHn"
DIR_NAME = f"/mnt/vdb/djc/work_djc/token_usage/{API_KEY[-8:]}/{get_fixed_date_advanced(date.today()).strftime('%Y%m%d')}"
os.makedirs(DIR_NAME, exist_ok=True)

# 日志文件锁，用于并发场景下的线程安全
proxy_log_lock = threading.Lock()
messages_log_lock = threading.Lock()


# 文件分片相关：每个文件最多 5K 条记录
MAX_ENTRIES_PER_FILE = 5000
_current_file_index = 1
_current_file_count = 0
_file_count_lock = threading.Lock()

def get_tokens(usage):
    prompt_tokens = 0
    completion_tokens = 0
    for key, value in usage.items():
        if isinstance(value, int):
            if "input" in key:
                prompt_tokens += value
            if "output" in key:
                completion_tokens += value
        if isinstance(value, dict):
            for value_key, value_value in value.items():
                if isinstance(value_value, int):
                    if "input" in value_key:
                        prompt_tokens += value_value
                    if "output" in value_key:
                        completion_tokens += value_value
    return prompt_tokens, completion_tokens

def log_format(line_json):
    
    prompt_tokens = 0
    completion_tokens = 0
    stream = line_json["response"].get("stream", False)
    response = line_json["response"]
    model = line_json["request"].get("model")
    if stream:
        for chunk in response["chunks"]:
            if chunk.startswith("data: ") and "\"usage\"" in chunk:
                delta_content = json.loads(chunk[len("data: "):])
                if "usage" in delta_content:
                    prompt_tokens, completion_tokens = get_tokens(delta_content["usage"])
                    model = delta_content.get("model")
                else:
                    if "message" in delta_content:
                        prompt_tokens, completion_tokens = get_tokens(delta_content["message"]["usage"])
                        model = delta_content["message"].get("model")
    else:
        if response.get("usage"):
            prompt_tokens, completion_tokens = get_tokens(response.get("usage"))
            model = response.get("model")


    content = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "model": model,
        "user": "30072021",
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "success": True
    }
    
    return json.dumps(content, ensure_ascii=False) 


class BytesEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, bytes):
            return obj.decode('utf-8')  # 将bytes解码为字符串
        return super().default(obj)


def now_ms():
    """获取当前时间戳(毫秒)"""
    return int(time.time() * 1000)


def req_id():
    """生成请求 ID"""
    return f"{now_ms()}-{uuid.uuid4().hex[:8]}"


def _get_current_messages_file_path():
    """获取当前写入的 messages 日志文件路径（带分片索引）"""
    base_name = os.path.basename(MESSAGES_LOG_FILE).replace(".jsonl", "")
    dir_name = os.path.dirname(MESSAGES_LOG_FILE)
    if _current_file_index == 1:
        return MESSAGES_LOG_FILE
    return os.path.join(dir_name, f"{base_name}_{_current_file_index}.jsonl")


def _advance_file_if_needed(num_entries):
    """检查当前文件已写入条数，若超过 10K 则切换到下一个文件"""
    global _current_file_index, _current_file_count
    with _file_count_lock:
        _current_file_count += num_entries
        if _current_file_count >= MAX_ENTRIES_PER_FILE:
            _current_file_index += 1
            _current_file_count = 0

def log_line(obj, path, lock):
    """线程安全地记录日志到文件"""
    obj["timestamp"] = now_ms()
    if "rid" in obj and "response" in obj and "request" in obj:
        with lock:
            with open(f"{DIR_NAME}/{LOG_FILENAME}", "a", encoding="utf-8") as outfile:
                outfile.write(log_format(obj) + "\n")
            outfile.close()


def log_request(full_path, headers, payload, is_stream, rid):
    """记录下游请求到 proxy 日志"""
    log_line({
        "type": "downstream_request",
        "rid": rid,
        "path": full_path,
        "stream": is_stream,
        "headers": dict(headers),
        "body": payload,
    }, PROXY_LOG_FILE, proxy_log_lock)


def log_response_non_stream(full_path, status_code, headers, body, rid):
    
    """记录非流式上游响应到 proxy 日志"""
    log_line({
        "type": "upstream_response",
        "rid": rid,
        "path": full_path,
        "status_code": status_code,
        "headers": dict(headers),
        "body": body,
    }, PROXY_LOG_FILE, proxy_log_lock)


def log_message_pair(rid, request_data, response_data):

    message_entry = {
        "rid": rid,
        "request": request_data,
        "response": response_data,
    }
    try:
        with messages_log_lock:

            current_messages_file = _get_current_messages_file_path()
            with open(current_messages_file, "a", encoding="utf-8") as f:
                with open(f"{DIR_NAME}/{LOG_FILENAME}", "a", encoding="utf-8") as outfile:
               
                    message_entry["timestamp"] = now_ms()
                    if "rid" in message_entry and "response" in message_entry and "request" in message_entry:
                        outfile.write(log_format(message_entry) + "\n")

                    line = json.dumps(message_entry, ensure_ascii=False, cls=BytesEncoder) + "\n"
                    f.write(line)     

        # 更新文件计数并检查是否需要切换文件
        _advance_file_if_needed(1)

    except Exception as e:
        print(f"[警告] 无法批量写入 messages 日志: {e}")


def filtered_headers(in_headers):
    """过滤需要转发的请求头，保留原样只跳过必要的"""
    skip_headers = {"Host", "Content-Length", "Transfer-Encoding", "Connection"}
    return {k: v for k, v in in_headers.items() if k not in skip_headers}

@app.route('/v1/messages', methods=['POST'])
@app.route('/v1/messages<path:path>', methods=['POST'])
def proxy_messages(path=""):
    """代理 /v1/messages 端点"""
    # 获取完整请求路径
    query_str = request.query_string.decode() if request.query_string else ""
    full_path = f"/v1/messages{path}?{query_str}" if query_str else f"/v1/messages{path}"

    # 解析请求体
    payload = request.get_json(force=True, silent=False)
    
    stream = bool(payload.get("stream", False))

    rid = req_id()
    if "thinking" in payload:
        if payload["thinking"].get("type") == "adaptive":
            payload["thinking"]["type"] = "enabled"

    # 记录下游请求
    # log_request(full_path, request.headers, payload, stream, rid)

    # 构造上游 URL
    upstream_url = f"{UPSTREAM_BASE_URL}{full_path}"
    headers = filtered_headers(request.headers)

    if not stream:
        # ---------- 非流式：一次性请求上游 ----------
        r = requests.post(upstream_url, headers=headers, json=payload, timeout=600, verify=False)

        # 解析响应内容
        try:
            resp_json = r.json()
        except Exception:
            resp_json = {"_raw_text": r.text}

        # 记录上游响应
        # log_response_non_stream(full_path, r.status_code, r.headers, resp_json, rid)

        # 记录 request-response 对到 messages 日志
        log_message_pair(rid, payload, resp_json)

        # 排除不需要转发的响应头
        skip_response_headers = {"content-encoding", "content-length", "transfer-encoding", "connection"}
        response_headers = [
            (k, v) for k, v in r.headers.items()
            if k.lower() not in skip_response_headers
        ]

        return Response(
            r.content,
            status=r.status_code,
            headers=response_headers
        )

    # ---------- 流式：SSE/分块转发 ----------
    upstream = requests.post(
        upstream_url,
        headers=headers,
        json=payload,
        stream=True,
        timeout=600,
        verify=False
    )

    # 用于收集完整的流式内容
    stream_chunks = []

    def generate():
        """逐块读取上游输出，原样转发给下游"""
        try:
            buffer = ""
            for raw in upstream.iter_lines(decode_unicode=True):
                if raw is None:
                    continue
                if raw == "":
                    # SSE 的空行分隔；也要透传（保持客户端解析一致）
                    yield "\n"
                    continue   
                
                if raw.startswith("data:") or raw.startswith("event:"):
                    buffer = raw
                    if buffer.endswith("}"):
                        try:
                            buffer = buffer.encode('latin1').decode('utf-8')
                        except Exception as e:
                            print(e)
                        # 记录每一行 chunk
                        stream_chunks.append(buffer)
                        # log_line({
                        #     "type": "upstream_stream_chunk",
                        #     "rid": rid,
                        #     "path": full_path,
                        #     "line": buffer,
                        # }, PROXY_LOG_FILE, proxy_log_lock)
                        yield buffer + "\n"
                    
                    # # 原样转发
                    # yield raw + "\n"
                else:
                    buffer += raw

        finally:
            # 流结束时记录
            # log_line({
            #     "type": "upstream_stream_end",
            #     "rid": rid,
            #     "path": full_path,
            #     "status_code": upstream.status_code,
            # }, PROXY_LOG_FILE, proxy_log_lock)

            # 记录完整的 request-response 对到 messages 日志
            stream_response_data = {
                "stream": True,
                "chunks": stream_chunks,
                "status_code": upstream.status_code,
            }
            log_message_pair(rid, payload, stream_response_data)

    # 使用 stream_with_context 保持 Flask 请求上下文
    return Response(
        stream_with_context(generate()),
        status=upstream.status_code,
        content_type=upstream.headers.get("Content-Type", "text/event-stream"),
    )


@app.route('/v1/chat/completions', methods=['POST'])
@app.route('/v1/chat/completions<path:path>', methods=['POST'])
def proxy_openai_chat_completion(path=""):
    """代理 /v1/chat/completions 端点，通过 Blue-Green Bridge alias 路由转发"""
    # 解析请求体
    payload = request.get_json(force=True, silent=False)

    stream = bool(payload.get("stream", False))
    rid = req_id()

    # 提取 alias（优先使用请求体中的 alias，否则使用默认值）
    alias = DEFAULT_ALIAS

    # 构造 Blue-Green Bridge 上游 URL
    upstream_url = f"{BLUE_GREEN_BASE_URL}{BLUE_GREEN_PREFIX}/chat_completions"

    # 构造 Blue-Green Bridge 所需的请求头
    headers = {
        "X-HW-ID": X_HW_ID,
        "X-HW-AppKey": X_HW_APPKEY,
        "Content-Type": "application/json",
    }
    # 保留原始 Authorization 头（如有）
    if "Authorization" in request.headers:
        headers["Authorization"] = request.headers["Authorization"]

    # 构造转发请求体：将 alias 放回，其余字段原样保留
    
    forward_payload = {"alias": alias}
    forward_payload.update(payload)

    if 'model' in forward_payload:
        del forward_payload['model']

    #print(f'{forward_payload=}')

    if not stream:
        # ---------- 非流式：一次性请求上游 ----------
        r = requests.post(upstream_url, headers=headers, json=forward_payload, timeout=600, verify=False)

        # 解析响应内容
        try:
            resp_json = r.json()
        except Exception:
            resp_json = {"_raw_text": r.text}

        # 记录 request-response 对到 messages 日志
        log_message_pair(rid, forward_payload, resp_json)

        # 排除不需要转发的响应头
        skip_response_headers = {"content-encoding", "content-length", "transfer-encoding", "connection"}
        response_headers = [
            (k, v) for k, v in r.headers.items()
            if k.lower() not in skip_response_headers
        ]

        return Response(
            r.content,
            status=r.status_code,
            headers=response_headers
        )

    # ---------- 流式：SSE/分块转发 ----------
    upstream = requests.post(
        upstream_url,
        headers=headers,
        json=forward_payload,
        stream=True,
        timeout=600,
        verify=False
    )

    # 用于收集完整的流式内容
    stream_chunks = []

    def generate():
        """逐块读取上游输出，原样转发给下游"""
        try:
            buffer = ""
            for raw in upstream.iter_lines(decode_unicode=True):
                if raw is None:
                    continue
                if raw == "":
                    yield "\n"
                    continue

                if raw.startswith("data:") or raw.startswith("event:"):
                    buffer = raw
                    if buffer.endswith("}"):
                        try:
                            buffer = buffer.encode('latin1').decode('utf-8')
                        except Exception as e:
                            print(e)
                        stream_chunks.append(buffer)
                        yield buffer + "\n"
                else:
                    buffer += raw

        finally:
            stream_response_data = {
                "stream": True,
                "chunks": stream_chunks,
                "status_code": upstream.status_code,
            }
            log_message_pair(rid, forward_payload, stream_response_data)

    return Response(
        stream_with_context(generate()),
        status=upstream.status_code,
        content_type=upstream.headers.get("Content-Type", "text/event-stream"),
    )

@app.route('/mcp_server', methods=['POST', 'GET'])
def forward_mcp_request():
    """转发请求到 MCP Server"""
    url = request.args.get("url")
    # 构建目标 URL
    target_url = "https://" + url + "?api_key=0935171d-17d5-4bd6-896c-a92f29132ea8&profile=monetary-anteater-CCaAaT"
    if request.query_string:
        target_url += f"?{request.query_string.decode()}"
    
    # 准备转发的请求头（排除 Host 等不需要的）
    # print(request.headers)
    forward_headers = {
        key: value for key, value in request.headers.items()
        if key.lower() not in ['host', 'content-length', 'connection', "accept-encoding"]
    }
    # Add Authorization header for Devin MCP server
    if "devin" in url:
        forward_headers["Authorization"] = "Bearer devin_sk_live_3f1b2c9a7d4e5f8a1c6b0d2e9f4a7c3b"
    # Add Authorization header for Strale MCP server
    if "strale" in url:
        forward_headers["Authorization"] = "Bearer sk_live_Q26_2EURFREE_1a2b3c4d5e6f7g8h9i0j"
    # Add Authorization header for AgentMail MCP server
    if "agentmail" in url:
        forward_headers["Authorization"] = "Bearer am_sk_live_8c7d2e9f1a0b4c3d5e6f7a2b1c9d8e7f01234567"
    # print(forward_headers)
    # 获取请求体
    request_body = request.get_data()
    data = {
        "headers": forward_headers,
    }

    if request.get_data():
        data["data"] = request.get_data()
    
    try:
        # 转发请求
        resp = requests.request(
            method=request.method,
            url=target_url,
            timeout=600,
            allow_redirects=False,
            **data
        )
        # print(resp.text)
        # 返回响应
        return Response(
            response=resp.content,
            status=resp.status_code,
            headers={k: v for k, v in resp.headers.items() 
                    if k.lower() not in ['content-encoding', 'transfer-encoding']}
        )
        
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}, 500


if __name__ == '__main__':
    import sys

    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8')

    # 清空日志文件

    if not os.path.exists(MESSAGES_LOG_FILE):
    #open(PROXY_LOG_FILE, "w", encoding="utf-8").close()
        open(MESSAGES_LOG_FILE, "w", encoding="utf-8").close()

    print("=" * 70)
    print("CLI API 中间人代理服务器")
    print("=" * 70)
    print(f"监听地址: http://localhost:8899")
    print(f"转发目标: {UPSTREAM_BASE_URL}")
    print(f"完整日志: {PROXY_LOG_FILE}")
    print(f"消息日志: {MESSAGES_LOG_FILE}")
    print("=" * 70 + "\n")

    # threaded=True 支持并发处理
    app.run(host='0.0.0.0', port=8899, debug=False, threaded=True)