
import json
import os

import httpx
from openai import OpenAI

def read_json_data(path, **kwargs):
    data = []
        
    with open(path, 'r',encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            row = json.loads(line)
            data.append(row)
    return data

def write_to_json(data, path, **kwargs):
    
    if 'mode' in kwargs:
        with open(path, kwargs['mode'], encoding='utf-8') as fout:
            for id, row in enumerate(data):
                if 'indent' in kwargs:
                    fout.write(json.dumps(row, ensure_ascii=False, indent=kwargs['indent']) + "\n")
                else:
                    fout.write(json.dumps(row, ensure_ascii=False) + "\n")
    else:
        with open(path, "a", encoding='utf-8') as fout:
            for id, row in enumerate(data):
                if 'indent' in kwargs:
                    fout.write(json.dumps(row, ensure_ascii=False, indent=kwargs['indent']) + "\n")
                else:
                    fout.write(json.dumps(row, ensure_ascii=False) + "\n")
def get_non_preprocess_env_task():


    tasks_dir = os.path.join(os.path.dirname(__file__), "tasks", "finalpool")
    mcp_servers = set()

    for task_folder in os.listdir(tasks_dir):
        task_path = os.path.join(tasks_dir, task_folder)
        if not os.path.isdir(task_path):
            continue

        config_path = os.path.join(task_path, "task_config.json")
        if not os.path.isfile(config_path):
            continue

        with open(config_path, "r") as f:
            config = json.load(f)

        for server in config.get("needed_mcp_servers", []):
            mcp_servers.add(server)


        has_preprocess = os.path.isdir(os.path.join(task_path, "preprocess"))
        has_scripts = os.path.isdir(os.path.join(task_path, "scripts"))
     
        if has_preprocess or has_scripts:
            prefix = task_folder.split("-")[0]
            mcp_servers.discard(prefix)

    return mcp_servers

def find_problem_task():
    p = '/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/dumps_public_service/job_acd6220651c4/finalpool'
    problem_task = set()
    for task_folder in os.listdir(p):
        token_usage_path = os.path.join(p, task_folder, 'token_usage.jsonl')
        if not os.path.exists(token_usage_path):
            problem_task.add(task_folder)

    with open('/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/problem_task.txt', 'r', encoding='utf-8') as f:
        for line in f.readlines():
            if line.strip() not in problem_task:
                problem_task.add(line.strip())
    f.close()

    with open('/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/problem_task.txt', 'w', encoding='utf-8') as f:
        for task in problem_task:
            f.write(task + '\n')
    f.close()

    
def get_trajectory_data(job_path):
    for task_folder in os.listdir(job_path):
        traj_data_path = os.path.join(job_path, task_folder, 'traj_log.json')

        with open(traj_data_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            messages = data['messages']

def pangu_test():
    httpx_client = httpx.Client(http2=True, verify=False)
    model_api = {
        'pangu_auto': {
            'base_url': "https://apigw-dgg-b0.huawei.com/api/pangu/v1",
            "key": "aCcENwfRYGfJ-VrGcBhkcvznD5UqQb7sJ4-DRfKLgRKpn7IWd-O6GU8efeP4N1caeYHH6I_ZBV_0RjSE9lattA"
        }
    }

    client = OpenAI(
        api_key=model_api['pangu_auto']['key'],
        base_url=model_api['pangu_auto']['base_url'],
        http_client=httpx_client
    )


    response = client.chat.completions.create(
        messages=[{"role": "user", "content": "Hello, who are you?"}],
        model="pangu_ultra_moe",
        extra_headers={
            "X-HW-ID": "S008151",
            "X-HW-AppKey": "hgXXZtkXVPDIS97C6obz/w==",
        },
        extra_body={"alias": "ziang-test"},
    )
    print(response)


def count_token():
    p = '/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/dumps_public_service'
    total_count = {
        'input_tokens': 0,
        'output_tokens': 0,
        'total_tokens': 0
    }
    c = 0
    for job_id in os.listdir(p):
        if not job_id.startswith('job'):
            continue
        pp = os.path.join(p, job_id, 'finalpool')
        for task_id in os.listdir(pp):
            token_usage_path = os.path.join(pp, task_id, 'token_usage.jsonl')

            if os.path.exists(token_usage_path):
                c += 1
                data = read_json_data(token_usage_path)

                for row in data:
                    total_count['input_tokens'] += row['input_tokens']
                    total_count['output_tokens'] += row['output_tokens']
                    total_count['total_tokens'] += row['total_tokens']

        

    print(total_count, c)
# get_trajectory_data('/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/dumps_public_service/job_5cc58f35c1a6/finalpool')


from openai import OpenAI
# from transformers import AutoTokenizer


# tokenizer = AutoTokenizer.from_pretrained(
#     os.path.join(os.getcwd(), 'pangu_tokenizer_llama3_expand_13b_v2_deleted'),
#     trust_remote_code=True
# )


request_example = read_json_data('/mnt/vdb/djc/work_djc/Toolathlon_new/Toolathlon/cc_trace-master/log/example.jsonl')

failed_request = request_example[0]
success_request = request_example[1]

client = OpenAI(
    api_key='random_x',
    base_url='http://localhost:8899/v1'
)


# response = client.chat.completions.create(
#     messages=success_request['messages'],
#     model='pangu_moe',
#     tools=success_request['tools']
# )

response = client.chat.completions.create(
    messages=failed_request['messages'],
    model='pangu_moe',
    tools=failed_request['tools']
)

print(response)
