import os
import json
import re

# Path to extracted claims
extracted_path = "/workspace/dumps/workspace/extracted_claims"

def read_pdf_content(pdf_path):
    """Read PDF content using pdf-tools"""
    try:
        # Use the pdf-tools function via subprocess or direct call
        # For now, let's read the PDF files directly
        import subprocess
        result = subprocess.run(
            ['pdftotext', pdf_path, '-'],
            capture_output=True,
            text=True
        )
        return result.stdout if result.returncode == 0 else None
    except Exception as e:
        return None

def process_claim(claim_id):
    """Process a single expense claim"""
    claim_path = os.path.join(extracted_path, claim_id)
    
    if not os.path.exists(claim_path):
        return {"claim_id": claim_id, "error": "Claim directory not found"}
    
    result = {
        "claim_id": claim_id,
        "employee_name": None,
        "employee_id": None,
        "employee_level": None,
        "department": None,
        "destination": None,
        "total_amount": None,
        "expenses": [],
        "invoices": [],
        "issues": [],
        "status": "pending"
    }
    
    # Read main claim PDF
    main_pdf = os.path.join(claim_path, f"expense_claim_{claim_id}_main.pdf")
    if os.path.exists(main_pdf):
        main_content = read_pdf_content(main_pdf)
        result["main_content"] = main_content
        
        # Extract employee info and total amount
        if main_content:
            text = main_content
            
            # Extract employee details
            emp_name_match = re.search(r'Employee Name:\s*(\w+ \w+)', text)
            if emp_name_match:
                result["employee_name"] = emp_name_match.group(1)
            
            emp_id_match = re.search(r'Employee ID:\s*(EMP\d+)', text)
            if emp_id_match:
                result["employee_id"] = emp_id_match.group(1)
            
            emp_level_match = re.search(r'Employee Level:\s*(L\d)', text)
            if emp_level_match:
                result["employee_level"] = emp_level_match.group(1)
            
            dept_match = re.search(r'Department:\s*(\w+ \w+)', text)
            if dept_match:
                result["department"] = dept_match.group(1)
            
            dest_match = re.search(r'Destination:\s*(.+)', text)
            if dest_match:
                result["destination"] = dest_match.group(1).strip()
            
            total_match = re.search(r'Total Amount:\s*CNY([\d,.]+)', text)
            if total_match:
                result["total_amount"] = float(total_match.group(1).replace(',', ''))
            
            # Extract expense items
            expense_pattern = r'(\d+)\t(\d{4}-\d{2}-\d{2})\t(\w+)\t(\w+)\t([\d,.]+)\t(.+)'
            for match in re.finditer(expense_pattern, text):
                expense = {
                    "no": int(match.group(1)),
                    "date": match.group(2),
                    "city": match.group(3),
                    "category": match.group(4),
                    "amount": float(match.group(5).replace(',', '')),
                    "description": match.group(6).strip()
                }
                result["expenses"].append(expense)
    
    # Read invoices
    invoice_files = sorted([f for f in os.listdir(claim_path) if f.startswith(f"expense_claim_{claim_id}_invoice_") and f.endswith(".pdf")])
    
    for inv_file in invoice_files:
        inv_path = os.path.join(claim_path, inv_file)
        inv_content = read_pdf_content(inv_path)
        
        invoice_info = {
            "file": inv_file,
            "content": inv_content,
            "has_receipt": True,
            "amount": None,
            "category": None
        }
        
        if inv_content:
            text = inv_content
            
            # Check for "No receipt available" message
            if "No receipt available" in text:
                invoice_info["has_receipt"] = False
                invoice_info["issue"] = "No receipt available"
                result["issues"].append(f"Invoice {inv_file}: No receipt available")
            
            # Extract amount
            amount_match = re.search(r'Amount:\s*CNY([\d,.]+)', text)
            if amount_match:
                invoice_info["amount"] = float(amount_match.group(1).replace(',', ''))
            
            # Extract category
            cat_match = re.search(r'Category:\s*(\w+)', text)
            if cat_match:
                invoice_info["category"] = cat_match.group(1)
        
        result["invoices"].append(invoice_info)
    
    # Verify completeness and amounts
    if len(result["expenses"]) > 0:
        # Check if number of invoices matches number of expenses
        if len(result["invoices"]) < len(result["expenses"]):
            result["issues"].append(f"Missing invoices: {len(result['expenses']) - len(result['invoices'])} expenses without supporting documents")
        
        # Check if amounts match
        for i, expense in enumerate(result["expenses"]):
            if i < len(result["invoices"]):
                invoice = result["invoices"][i]
                if invoice["has_receipt"] and invoice["amount"] is not None:
                    if abs(expense["amount"] - invoice["amount"]) > 0.01:
                        result["issues"].append(f"Expense {expense['no']} ({expense['category']}): Amount mismatch - Claimed: CNY{expense['amount']}, Invoice: CNY{invoice['amount']}")
    
    # Determine status
    if result["issues"]:
        result["status"] = "review_required"
    else:
        result["status"] = "complete"
    
    return result

# Process all claims
claims = []
for claim_id in sorted(os.listdir(extracted_path)):
    if os.path.isdir(os.path.join(extracted_path, claim_id)):
        claim_result = process_claim(claim_id)
        claims.append(claim_result)

# Save results to JSON
output_path = "/workspace/dumps/workspace/claim_analysis.json"
with open(output_path, 'w') as f:
    json.dump(claims, f, indent=2)

print(f"Processed {len(claims)} claims")
print(f"Results saved to: {output_path}")

# Print summary
for claim in claims:
    print(f"\n{claim['claim_id']}: {claim['employee_name']} - {claim['department']}")
    print(f"  Total: CNY{claim['total_amount']}")
    print(f"  Expenses: {len(claim['expenses'])}, Invoices: {len(claim['invoices'])}")
    print(f"  Status: {claim['status']}")
    if claim['issues']:
        print(f"  Issues:")
        for issue in claim['issues']:
            print(f"    - {issue}")