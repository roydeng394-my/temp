import tarfile
import os
import json
import shutil

# Extract all expense claims
workspace_path = "/workspace/dumps/workspace"
files_path = os.path.join(workspace_path, "files")

# Create a directory for extracted claims
extracted_path = os.path.join(workspace_path, "extracted_claims")
os.makedirs(extracted_path, exist_ok=True)

# Extract each tar.gz file
for filename in os.listdir(files_path):
    if filename.endswith(".tar.gz") and "expense_claim" in filename:
        file_path = os.path.join(files_path, filename)
        claim_id = filename.replace("expense_claim_", "").replace(".tar.gz", "")
        claim_extract_path = os.path.join(extracted_path, claim_id)
        os.makedirs(claim_extract_path, exist_ok=True)
        
        try:
            with tarfile.open(file_path, "r:gz") as tar:
                tar.extractall(claim_extract_path)
            print(f"Extracted: {filename} -> {claim_id}")
        except Exception as e:
            print(f"Error extracting {filename}: {e}")

print("\nExtraction complete!")